export const ADD_BOOK = 'ADD_BOOK'
export const DELETE_BOOK = 'DELETE_BOOK'
export const TOGGLE_FAVOURITE = 'TOGGLE_FAVOURITE'
